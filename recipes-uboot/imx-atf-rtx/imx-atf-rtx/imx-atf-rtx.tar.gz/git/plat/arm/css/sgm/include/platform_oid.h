/*
 * Copyright (c) 2018, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */
#include "../../../../../include/plat/arm/board/common/board_arm_oid.h"

/*
 * Required platform OIDs
 * (Provided by included header)
 */
