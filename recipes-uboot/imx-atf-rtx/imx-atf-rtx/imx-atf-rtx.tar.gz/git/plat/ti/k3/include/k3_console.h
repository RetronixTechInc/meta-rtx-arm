/*
 * Copyright (c) 2017-2018, ARM Limited and Contributors. All rights reserved.
 *
 * SPDX-License-Identifier: BSD-3-Clause
 */

#ifndef __K3_CONSOLE_H__
#define __K3_CONSOLE_H__

void bl31_console_setup(void);

#endif /* __K3_CONSOLE_H__ */
